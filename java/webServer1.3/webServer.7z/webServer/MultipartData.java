package webServer;

public final class MultipartData
{
	public String name;

	public String filename;

	public byte[] bArray;
}