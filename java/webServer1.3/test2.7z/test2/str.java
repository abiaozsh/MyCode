package test2;

public class str
{
	public static void main(String[] args)throws Exception
	{
		String s = "in string";
		byte[] b = s.getBytes("sjis");
		String out = new String(b,"utf-8");
		System.out.print(out);
	}

}
