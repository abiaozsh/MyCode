package test2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class test
{
	public static void main(String[] args) throws Exception
	{
		HashMap<String, String> hm = new HashMap<String, String>();

		File f1 = new File("D:\\新しいフォルダ\\southpark\\South Park S04E17.cn.srt");
		File f2 = new File("D:\\新しいフォルダ\\southpark\\South Park S04E17.en.srt");
		File fo = new File("D:\\新しいフォルダ\\southpark\\South.Park.S04E17.A.Very.Crappy.Christmas.srt");
		FileInputStream fis1 = new FileInputStream(f1);
		FileInputStream fis2 = new FileInputStream(f2);
		FileOutputStream fos = new FileOutputStream(fo);
		int len;

		byte[] buff = new byte[1024 * 1024];

		len = fis1.read(buff);
		String s1 = new String(buff, 0, len, "GBK");
		fis1.close();

		len = fis2.read(buff);
		String s2 = new String(buff, 0, len, "GBK");
		fis2.close();

		String[] ss1 = s1.split("\r\n\r\n");
		for (int i = 0; i < ss1.length; i++)
		{
			String[] sss1 = ss1[i].split("\r\n", 3);
			if (sss1.length <= 2)
			{
				hm.put(sss1[1], "");
			}
			else
			{
				hm.put(sss1[1], sss1[2]);
			}
		}

		String[] ss2 = s2.split("\r\n\r\n");
		for (int i = 0; i < ss2.length; i++)
		{
			String[] sss2 = ss2[i].split("\r\n", 3);

			if (sss2[0].length() < 5)
			{
				String shm = hm.get(sss2[1]);
				String s22 = "";
				while (sss2[2].length() > 0) {
					try {
						s22 = s22 + sss2[2].substring(0, 40)+"\r\n";
					} catch (Exception e) {
						s22 = s22 + sss2[2]+"\r\n";
					}
					try {
						sss2[2] = sss2[2].substring(40);
					} catch (Exception e) {
						sss2[2] = "";
					}
				}
				if (shm == null)
				{
					hm.put(sss2[1], s22);
				}
				else
				{
					hm.put(sss2[1], s22 + "\r\n" + shm);
				}
			}
			else
			{
				sss2[0] = sss2[0]+"0";
				String shm = hm.get(sss2[0]);
				if (shm == null)
				{
					hm.put(sss2[0], sss2[1]);
				}
				else
				{
					hm.put(sss2[0], sss2[1] + "\r\n" + shm);
				}
			}
		}
		Object[] o = hm.entrySet().toArray();
		List<Entry> l = new ArrayList<Entry>();

		for (int i = 0; i < o.length; i++)
		{
			l.add((Entry) o[i]);
		}

		Sorter s = new Sorter();
		Collections.<Entry> sort(l, s);

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < l.size(); i++)
		{
			Entry e = l.get(i);
			sb.append(i + "\r\n");
			sb.append(e.getKey() + "\r\n");
			sb.append(e.getValue() + "\r\n");
			sb.append("\r\n");
		}

		fos.write(sb.toString().getBytes("unicode"));
		fos.close();
	}

}

class Sorter implements Comparator<Entry>
{
	public int compare(Entry e1, Entry e2)
	{
		return ((String) e1.getKey()).compareTo((String) e2.getKey());
	}
}

class text
{
	String time;

	String text;
}