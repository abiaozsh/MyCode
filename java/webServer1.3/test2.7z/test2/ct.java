package test2;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class ct
{
	public static void main(String[] args) throws Exception
	{
		try
		{
			int port = 148;
			String hostname = "192.168.5.23";

			X509TrustManager xtm = new MyTrustManager();
			TrustManager mytm[] = { xtm };
			SSLContext ctx = SSLContext.getInstance("SSL");
			ctx.init(null, mytm, null);
			SSLSocketFactory sslSF = ctx.getSocketFactory();
			SSLSocket socket = (SSLSocket) sslSF.createSocket(hostname, port);

			OutputStream out = socket.getOutputStream();

			OutputStreamWriter osw = new OutputStreamWriter(out);
			PrintWriter pw = new PrintWriter(osw);

			pw.println("GET Tanmatsu/getJspStream?flg=1 HTTP/1.1");
			pw.println("Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
			pw.println("Accept-Language: ja");
			pw.println("Accept-Encoding: gzip, deflate");
			pw.println("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1; .NET CLR 1.1.4322)");
			pw.println("Host: 198.198.198.254");
			pw.println("Connection: close");
			pw.println("");

			pw.flush();
			out.flush();

			byte[] buf = new byte[65536];
			InputStream in = socket.getInputStream();

			int len = in.read(buf);

			String s = new String(buf, 0, len, "ISO-8859-1");

			System.out.print(s);
			// Close the socket
			in.close();

			out.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}

class MyTrustManager implements X509TrustManager
{
	public void checkClientTrusted(X509Certificate chain[], String authType)
	{
		//
	}

	public void checkServerTrusted(X509Certificate chain[], String authType)
	{
		//
	}

	public X509Certificate[] getAcceptedIssuers()
	{
		return null;
	}
}
