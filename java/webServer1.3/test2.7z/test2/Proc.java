package test2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Proc extends Thread
{
	private InputStream si;

	private OutputStream so;

	private String io;

	private String path;

	public Proc(InputStream si, OutputStream so, String io, String path)
	{
		this.si = si;
		this.so = so;
		this.io = io;
		this.path = path;
	}

	@Override
	public void run()
	{
		FileOutputStream fo = null;
		try
		{
			SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
			Date d = new Date();

			int idx = 0;
			while (true)
			{
				File file = new File(path + f.format(d) + io + idx + ".txt");

				if (!file.exists())
				{
					break;
				}
				else
				{
					idx++;
				}
			}

			fo = new FileOutputStream(path + f.format(d) + io + idx + ".txt");

			if ("I".equals(io))
			{
				SimpleDateFormat sdf = new SimpleDateFormat("HHmmss:SSS");
				fo.write((sdf.format(new Date()) + "\r\n").getBytes());
				byte[] c = new byte[256];
				while (true)
				{
					int cnt = si.read(c);
					if (cnt == -1) break;

					fo.write(c, 0, cnt);
					so.write(c, 0, cnt);
				}
				fo.write("\r\n".getBytes());
			}
			else
			{
				byte[] c = new byte[256];
				SimpleDateFormat sdf = new SimpleDateFormat("HHmmss:SSS");
				fo.write((sdf.format(new Date()) + "\r\n").getBytes());
				while (true)
				{
					int cnt = si.read(c);
					if (cnt == -1) break;

					fo.write(c, 0, cnt);
					so.write(c, 0, cnt);
				}
				fo.write("\r\n".getBytes());
			}
		}
		catch (SocketException e)
		{
			System.out.print(e);
		}
		catch (IOException e)
		{
			System.out.print(e);
		}
		finally
		{
			try
			{
				fo.close();
				si.close();
				so.close();
			}
			catch (Exception e)
			{
				//
			}
		}
	}
}