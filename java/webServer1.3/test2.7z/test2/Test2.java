package test2;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Test2 {
	public static void main(String[] Args) {
		
		try {
			ServerSocket ss = new ServerSocket(81);
			while (true) {
				try {
					System.out.print("listening\n");
					Socket sock1 = ss.accept();
					InputStream si1 = sock1.getInputStream();
					OutputStream so1 = sock1.getOutputStream();
					//Socket sock2 = new Socket("64.233.167.99", 80);//google
					//Socket sock2 = new Socket("210.150.160.234", 80);//excite
					Socket sock2 = new Socket("www.google.cn", 80);
					InputStream si2 = sock2.getInputStream();
					OutputStream so2 = sock2.getOutputStream();
					Proc p1 = new Proc(si1, so2, "I", "d:\\bin\\");
					Proc p2 = new Proc(si2, so1, "O", "d:\\bin\\");
					p1.start();
					p2.start();
				} catch (Exception e) {
					System.out.print(e);
				}
			}
		} catch (Exception e) {
			System.out.print(e);
		}
	}
}