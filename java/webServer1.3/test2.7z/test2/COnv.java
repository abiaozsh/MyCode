package test2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class COnv
{
	static byte[] buff = new byte[1024*1024*10];
	public static void main(String[] args)throws Exception
	{
		File f = new File("d:\\src\\");
		conv(f);
		
	}
	private static void conv(File file)throws Exception
	{
		File[] fs = file.listFiles();
		for(File f:fs)
		{
			if(f.isDirectory())
			{
				conv(f);
			}
			else
			{
				System.out.println(f.getPath());
				FileInputStream fis = new FileInputStream(f);
				int len = fis.read(buff);
				fis.close();
				String s = new String(buff,0,len,"MS932");
				FileOutputStream fos = new FileOutputStream(f);
				fos.write(s.getBytes("utf-8"));
				fos.close();
			}
		}
	}
}
