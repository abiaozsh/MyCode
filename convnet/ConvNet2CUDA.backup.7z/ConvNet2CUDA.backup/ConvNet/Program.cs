﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Lib;

namespace ConvNet
{
	class Program
	{


		static void Main(string[] args)
		{
			int n = Util.initGPU(0);
			Console.WriteLine(n);

			FCFWD_Test.Test();
			FCBWD_Test.Test();
			CVFWD_Test.Test();
			CVBWD_Test.Test();


			Console.ReadLine();

		}
	}
}
