﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        SerialPort port;

        public Form1()
        {
            InitializeComponent();

            this.FormClosed += new FormClosedEventHandler(Form1_FormClosed);

            if (port == null)
            {
                //COM4为Arduino使用的串口号，需根据实际情况调整
                port = new SerialPort("COM10", 9600);
                port.Open();
            }
        }

        void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (port != null && port.IsOpen)
            {
                port.Close();
            }
        }

        private void PortWrite(int chn, int data)
        {
            byte[] d = new byte[3];
            d[0] = (byte)(0x0D4 | chn);
            d[1] = (byte)(data & 0x0FF);
            d[2] = (byte)((data >> 8) & 0x0FF);
            if (port != null && port.IsOpen)
            {
                port.Write(d, 0, 3);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int data = int.Parse(textBox1.Text);

            int data2 = int.Parse(textBox2.Text);

            PortWrite(data, data2);

            //byte[] buff = new byte[100];
            //port.Read(buff, 0, 100);
            //int data2 = buff[0];
            //this.Text = data + " " + data2;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            double v = 20000 + ((double)trackBar1.Value) * (32000 - 20000) / 200;
            this.Text = v.ToString();
            PortWrite(0, (int)(v));
        }

    }
}


