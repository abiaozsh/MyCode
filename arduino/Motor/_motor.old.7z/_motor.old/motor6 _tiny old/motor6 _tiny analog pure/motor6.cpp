#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "motor6.h"

#define HaltRpm  11000
#define StartRpm 12000

#define CmdNextStep Step = NextStep[Step];
uint8_t NextStep[] = {
  1,  2,  3,  4,  5,  0
};
//pwm on
#define CmdPWROn  PORT6O = PWR_ON[Step];
//pwm off
#define CmdPWROff PORT6O = PWR_OFF[Step];

uint8_t PWR_ON[] = {
	BP1U + BP1D + BP3D, // 1-2
	BP1U + BP1D + BP2D, // 1-3
	BP2U + BP1D + BP2D, // 2-3
	BP2U + BP3D + BP2D, // 2-1
	BP3U + BP3D + BP2D, // 3-1
	BP3U + BP1D + BP3D  // 3-2
};
uint8_t PWR_OFF[] = {
	0    + BP1D + BP3D, // 1-2
	0    + BP1D + BP2D, // 1-3
	0    + BP1D + BP2D, // 2-3
	0    + BP3D + BP2D, // 2-1
	0    + BP3D + BP2D, // 3-1
	0    + BP1D + BP3D  // 3-2
};

#define GetDigitRead (PIN3I & DigitRead[Step])
uint8_t DigitRead[] = {
  BP3A,  BP2A,  BP1A,  BP3A,  BP2A,  BP1A 
};
#define GetDigitReadBaseVal (DigitReadBaseVal[Step])
uint8_t DigitReadBaseVal[] = {
  BP3A,     0,  BP1A,     0,  BP2A,     0
};

byte Power = 0;
byte Step = 0;
byte Status = 0;//0 halt ,1 running, 2 starting
byte StartUpCount1=0;
byte StartUpCount2=0;
unsigned int rpm;

void ClockInit();
void TimerInit();
void AnalogInit();
void wait(unsigned int ticks);
void loop();
void waita();
void adj();

int main(void) {
	ClockInit();//��ʼ��ʱ�ӣ�1MHz -> 8MHz
	TimerInit();//��ʼ����ʱ�� 1/8
	AnalogInit();//��ʼ��ģ������

	DDRA = 0;PORTA = 0;//all input
	DDRB = 0;PORTB = 0;//all input

	//�ȴ�1�������ź� Pin6�ߵ�ƽ  wait till 1s power on signal
	int cnt = 0;
	while(true)
	{
		wait(1000);
		if(drA6==0)// power on signal
		{
			cnt=0;
		}
		cnt++;
		if(cnt>=1000)
		{
			break;
		}
	}

	//������˿�
	DDR6O = BP1U | BP1D | BP2U | BP2D | BP3U | BP3D;
	
	//��ʼ������˿�
	PORT6O = BP1D | BP2D | BP3D;
	
	//��ʼ������˿�
	DDR3I = 0;
	PORT3I = 0;

	//��ѭ��
	loop();
}

void wait(unsigned int ticks) {
	TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
	while(currTick<ticks)
	{
		;
	}
}

void ClockInit() {
	CLKPR = 128;//The CLKPCE bit must be written to logic one to enable change of the CLKPS bits. The CLKPCE bit is only updated when the other bits in CLKPR are simultaniosly written to zero.
	//CLKPR = 3;//1/8
	CLKPR = 0;//1/1 //8MHz
}

void TimerInit() {
	TCCR1A = 0;
	TCCR1B = 2;//  1/8	1MHz 1us
	TCCR1C = 0;
	TIMSK1 = 0;
}

void AnalogInit() {
	ADMUX = 7;//A7 rpm
	ADCSRA = _BV(ADEN) | _BV(ADSC) | _BV(ADPS0) | _BV(ADPS1) | _BV(ADPS2);
	ADCSRB = _BV(ADLAR);
}

void loop() {
	for(;;) {
		//��ʱ������
		TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
		adj();
		//����
		if(Power)
		{
			CmdPWROn;
		}
		else
		{
			CmdPWROff;
		}
		//�ȴ�����
		waita();
		CmdNextStep;
		//��¼��ǰת��
		rpm = currTick;
	}
}

void waita() {
	unsigned int temp = (rpm>>1);//(rpm>>2)+40 or +80 //big for slow ,small for fast 
	//pre wait time
	while(currTick<temp){}
	byte valbase = GetDigitReadBaseVal;//;//;GetDigitRead
	while(true)
	{
		byte val = GetDigitRead;
		if(val!=valbase){
			CmdPWROff;
			return;
		}
		if(currTick>MaxPonTime){
			CmdPWROff;
		}
	}
}

void adj() {
	Power = 0;
	unsigned int ticks = ADCH;
	unsigned int TargetRPM = ticks<<5;// TODO 512byte convert table  *32 8000max
	sbi(ADCSRA, ADSC);
	if(Status == 1)
	{
		if(rpm>HaltRpm)//too slow, halt
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Status = 0;//halt
		}
		else if(rpm>TargetRPM)//bit slow && running
		{
			Power = 0x0FF;
		}
	}
	else
	{
		if(rpm<StartRpm&&rpm>(StartRpm>>3))//fast enough but not too fast
		{
			StartUpCount1++;
		}
		else
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
		}
		if(StartUpCount1>20)
		{
			Power = 0x0FF;
		}
		if(rpm<HaltRpm&&rpm>(HaltRpm>>3))//fast enough but not too fast
		{ 
			StartUpCount2++;
		}
		else
		{ 
			StartUpCount2=0;
		}
		if(StartUpCount2>20)
		{
			Status=1;
		}
	}
}




