#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "motor6.h"

#define IdleRPM  2000
#define HaltRpm  7000
#define StartRpm 8000

#define CmdNextStep Step = NextStep[Step];
uint8_t NextStep[] = {
  1,  2,  3,  4,  5,  0
};
//pwm on
#define CmdPWROn  PORT6O = PWR_ON[Step] | (flg & _BV(6));
//pwm off
#define CmdPWROff PORT6O = PWR_OFF[Step] | (flg & _BV(6));

uint8_t PWR_ON[] = {
	BP1U + BP1D + BP3D, // 1-2
	BP1U + BP1D + BP2D, // 1-3
	BP2U + BP1D + BP2D, // 2-3
	BP2U + BP3D + BP2D, // 2-1
	BP3U + BP3D + BP2D, // 3-1
	BP3U + BP1D + BP3D  // 3-2
};
uint8_t PWR_OFF[] = {
	0    + BP1D + BP3D, // 1-2
	0    + BP1D + BP2D, // 1-3
	0    + BP1D + BP2D, // 2-3
	0    + BP3D + BP2D, // 2-1
	0    + BP3D + BP2D, // 3-1
	0    + BP1D + BP3D  // 3-2
};

#define GetDigitRead (PIN3I & DigitRead[Step])
uint8_t DigitRead[] = {
  BP3A,  BP2A,  BP1A,  BP3A,  BP2A,  BP1A 
};
#define GetDigitReadBaseVal (DigitReadBaseVal[Step])
uint8_t DigitReadBaseVal[] = {
  BP3A,     0,  BP1A,     0,  BP2A,     0
};

byte Power = 0;
byte Step = 0;
byte Status = 0;//0 halt ,1 running, 2 starting
byte StartUpCount1=0;
byte StartUpCount2=0;
byte flg = 0;
byte idleCnt = 0;
unsigned int rpm;

void ClockInit();
void TimerInit();
void wait(unsigned int ticks);
void loop();
void waita();
void adj();

int main(void) {
	ClockInit();
	TimerInit();

	DDRA = 0;PORTA = 0;//all input
	DDRB = 0;PORTB = 0;//all input
	
	//wait till 1s power on signal
	int cnt = 0;
	while(true)
	{
		wait(1000);
		if(drA7==0)
		{
			cnt=0;
		}
		cnt++;
		if(cnt>=1000)
		{
			break;
		}
	}
	
	DDR6O = BP1U | BP1D | BP2U | BP2D | BP3U | BP3D | _BV(6);
	
	PORT6O = BP1D | BP2D | BP3D;
	
	DDR3I = 0;
	PORT3I = 0;

	loop();
}

void ClockInit() {
	CLKPR = 128;//The CLKPCE bit must be written to logic one to enable change of the CLKPS bits. The CLKPCE bit is only updated when the other bits in CLKPR are simultaniosly written to zero.
	//CLKPR = 3;//1/8
	CLKPR = 0;//1/1 //8MHz
}

void TimerInit() {
	TCCR1A = 0;
	TCCR1B = 2;//  1/8	1MHz 1us
	TCCR1C = 0;
	TIMSK1 = 0;
}

void wait(unsigned int ticks) {
	TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
	while(currTick<ticks)
	{
		;
	}
}

void loop() {
	for(;;)
	{
		TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
		adj();
		flg=~flg;
		if(Power)
		{
			CmdPWROn;
		}
		else
		{
			CmdPWROff;
		}
		waita();
		CmdNextStep;
		rpm = currTick;
	}
}

void waita() {
	unsigned int temp = (rpm>>2);//(rpm>>2)+40 or +80 //big for slow ,small for fast 
	while(currTick<temp)
	{
		//pre wait time
	}
	byte valbase = GetDigitReadBaseVal;//;//;GetDigitRead
	byte notovertime = 0x0FF;
	while(true)
	{
		byte val = GetDigitRead;
		if(currTick>MaxPonTime){
			CmdPWROff;
			notovertime = 0;
		}
		if(val!=valbase){
			//afterdelay
			if(notovertime)
			{
				temp = currTick + (rpm>>1);
				while(currTick<temp)
				{
				}
				CmdPWROff;
			}
			return;
		}
	}
}

void adj() {
	byte TargetPower;
	if(drA7)
	{
		TargetPower = 0x0FF;
	}
	else
	{
		TargetPower = 0;
	}
	idleCnt++;
	if(idleCnt == 7)
	{
		idleCnt = 0;
	}
	
	if(Status == 1)
	{
		if(rpm>HaltRpm)//too slow, halt
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Status = 0;//halt
			Power = 0;
		}
		else if(rpm>IdleRPM)//bit slow && running
		{
			Power = TargetPower | (idleCnt==0?0x0FF:0x00);
		}
		else//fast
		{
			Power = TargetPower;
		}
	}
	else
	{
		if(rpm<StartRpm&&rpm>(StartRpm>>3))//fast enough but not too fast
		{
			StartUpCount1++;
		}
		else
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Power = 0;
		}
		if(StartUpCount1>20)
		{
			Power = 0x0FF;
		}
		else
		{ 
			Power = 0;
		}
		if(rpm<HaltRpm&&rpm>(HaltRpm>>3))//fast enough but not too fast
		{ 
			StartUpCount2++;
		}
		else
		{ 
			StartUpCount2=0;
		}
		if(StartUpCount2>20)
		{
			Status=1;
		}
	}
}




