﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        SerialPort port;

        public Form1()
        {
            InitializeComponent();

            this.FormClosed += new FormClosedEventHandler(Form1_FormClosed);

            if (port == null)
            {
                //COM4为Arduino使用的串口号，需根据实际情况调整
                port = new SerialPort("COM10", 9600);
                port.Open();
            }
        }

        void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (port != null && port.IsOpen)
            {
                port.Close();
            }
        }

        private void PortWrite(byte data)
        {
            byte[] d = new byte[6];
            d[0] = 49;
			d[1] = data;
			d[2] = 1;
			d[3] = 100;
			d[4] = 1;
			d[5] = 1;
			if (port != null && port.IsOpen)
            {
                port.Write(d, 0, 6);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int data = int.Parse(textBox1.Text);

            data *= 2;

            if (this.checkBox1.Checked)
            {
                PortWrite((byte)(data + 1));
            }
            else
            {
                PortWrite((byte)(data + 0));
            }

            //byte[] buff = new byte[100];
            //port.Read(buff, 0, 100);
            //int data2 = buff[0];
            //this.Text = data + " " + data2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 3; i < 54; i++)
            {
                int data = i;

                data *= 2;

                if (this.checkBox1.Checked)
                {
                    PortWrite((byte)(data + 1));
                }
                else
                {
                    PortWrite((byte)(data + 0));
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        int[] a = {
                      0,
                      0,
                      0,
                      1,//01
                      0,//02
                      1,//03
                      0,//04
                      1,//05
                      0,//06
                      1,//07
                      0,//08
                      1,//09
                      0,//10
                      1,//11
                      0,//12
                      1,//13
                      0,//14
                      1,//15
                      0,//16
                      1,//17
                      0,//18
                      1,//19
                      0,//20
                      1,//21
                      0,//22
                      1,//23
                      0,//24
                      1,//25
                      0,//26
                      1,//27
                      0,//28
                      1,//29
                      0,//30
                      1,//31
                      0,//32
                      1,//33
                      0,//34
                      1,//35
                      0,//36
                      1,//37
                      0,//38
                      1,//39
                      0,//40
                      1,//41
                      0,//42
                      1,//43
                      0,//44
                      1,//45
                      0,//46
                      1,//47
                      0,//48
                      1,//49
                      0,//50
                      1 //51
                  };

        private void Form1_Load(object sender, EventArgs e)
        {
            //for (int i = 3; i < 54; i++)
            //{
            //    int data = i;

            //    data *= 2;

            //    PortWrite((byte)(data + (i&1)));
            //}
           // timer1.Enabled = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int itext = int.Parse(this.textBox1.Text);

            if (itext > 3)
            {
                int data = itext - 1;
                data *= 2;
                PortWrite((byte)(data + 0));
            }

            {
                int data = itext;
                data *= 2;
                PortWrite((byte)(data + 1));
            }

            itext++;
            if (itext == 54) itext = 3;
            this.textBox1.Text = itext.ToString();
        }

        int flg=0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            int data = 1;
            
            data *= 2;

            if (flg==0)
            {
                PortWrite((byte)(data + 1));
                flg = 1;
            }
            else
            {
                PortWrite((byte)(data + 0));
                flg = 0;
            }
        }

    }
}


