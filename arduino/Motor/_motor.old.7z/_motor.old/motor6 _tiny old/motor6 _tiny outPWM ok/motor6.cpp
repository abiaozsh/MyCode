#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "motor6.h"

#define HaltRpm  7000
#define StartRpm 8000

#define CmdNextStep Step = pgm_read_byte_near(NextStep+Step);
PROGMEM prog_uint8_t NextStep[] = {
  1,  2,  3,  4,  5,  0
};

//pwm on
#define CmdPWROn  PORT6O = pgm_read_byte_near(PWR_ON+Step) | (flg & _BV(6));
//pwm off
#define CmdPWROff PORT6O = pgm_read_byte_near(PWR_OFF+Step) | (flg & _BV(6));

PROGMEM prog_uint8_t PWR_ON[] = {
	BP1U + BP1D + BP3D, // 1-2
	BP1U + BP1D + BP2D, // 1-3
	BP2U + BP1D + BP2D, // 2-3
	BP2U + BP3D + BP2D, // 2-1
	BP3U + BP3D + BP2D, // 3-1
	BP3U + BP1D + BP3D  // 3-2
};
PROGMEM prog_uint8_t PWR_OFF[] = {
	0    + BP1D + BP3D, // 1-2
	0    + BP1D + BP2D, // 1-3
	0    + BP1D + BP2D, // 2-3
	0    + BP3D + BP2D, // 2-1
	0    + BP3D + BP2D, // 3-1
	0    + BP1D + BP3D  // 3-2
};

#define GetDigitRead (PIN3I & pgm_read_byte_near(DigitRead+Step))
#define GetDigitReadBaseVal (pgm_read_byte_near(DigitReadBaseVal+Step))
PROGMEM prog_uint8_t DigitRead[] = {
	BP3A,  BP2A,  BP1A,  BP3A,  BP2A,  BP1A 
};
PROGMEM prog_uint8_t DigitReadBaseVal[] = {
	BP3A,     0,  BP1A,     0,  BP2A,     0
};

byte flg = 0;
byte Power = 0x00;//00/FF
byte Step = 0;
byte Status = 0;//0 halt ,1 running, 2 starting
byte StartUpCount1=0;
byte StartUpCount2=0;
byte valbase;
unsigned int rpm;

void ClockInit();
void TimerInit();
void wait(unsigned int ticks);
void loop();
byte waita();
void waitb();
void adj();

int main(void) {
	DDRA = 0;PORTA = 0;//all input
	DDRB = 0;PORTB = 0;//all input

	ClockInit();
	TimerInit();

	//wait till 1s power on signal
	int cnt = 0;
	while(true)
	{
		wait(1000);//1ms
		if(drA7)
		{
		}
		else
		{
			cnt=0;
		}
		cnt++;
		if(cnt>=1000)
		{
			break;
		}
	}

	//  //INPUT
	//  //    DDR &= ~_BV();PORT &= ~_BV();
	//  //output
	//  //    DDR |= _BV();
	//  DDR6O |= BP1U;//pMode(p1u, OUTPUT);//     7
	//  DDR6O |= BP1D;//pMode(p1d, OUTPUT);//     6
	//  DDR6O |= BP2U;//pMode(p2u, OUTPUT);//     5
	//  DDR6O |= BP2D;//pMode(p2d, OUTPUT);//     4
	//  DDR6O |= BP3U;//pMode(p3u, OUTPUT);//     3
	//  DDR6O |= BP3D;//pMode(p3d, OUTPUT);//     2
	DDR6O = BP1U | BP1D | BP2U | BP2D | BP3U | BP3D | _BV(6);

	//  //#define turnoffAll p1uL;p2uL;p3uL;p1dH;p2dH;p3dH;
	//  PORT6O &= ~BP1U; //up    A2
	//  PORT6O |=  BP1D; //down
	//  PORT6O &= ~BP2U; //up    A1
	//  PORT6O |=  BP2D; //down
	//  PORT6O &= ~BP3U; //up    A0
	//  PORT6O |=  BP3D; //down
	PORT6O = BP1D | BP2D | BP3D;
	//
	//  DDR3I &= ~BP1A;PORT3I &= ~BP1A;//pMode(A0, INPUT);//INPUT_PULLUP for comparator
	//  DDR3I &= ~BP2A;PORT3I &= ~BP2A;//pMode(A1, INPUT);//digit
	//  DDR3I &= ~BP3A;PORT3I &= ~BP3A;//pMode(A2, INPUT);//digit
	DDR3I = 0;
	PORT3I = 0;
	//
	//  DDRA |= _BV(6);//pMode(10, OUTPUT);
	//  DDRA &= ~_BV(7);PORTA &= ~_BV(7);//pMode(8, INPUT);

	loop();
}

inline void ClockInit() {
	CLKPR = 128;//The CLKPCE bit must be written to logic one to enable change of the CLKPS bits. The CLKPCE bit is only updated when the other bits in CLKPR are simultaniosly written to zero.
	//CLKPR = 3;//1/8
	CLKPR = 0;//1/1 //8MHz
}

inline void TimerInit() {
	// COM1A1 COM1A0 COM1B1 COM1B0 �C �C WGM11 WGM10
	TCCR1A = 0;

	//ICNC1 ICES1 �C WGM13 WGM12 CS12 CS11 CS10
	//0 0 1 clkI/O/1 (No prescaling)
	//0 1 0 clkI/O/8 (From prescaler)
	//0 1 1 clkI/O/64 (From prescaler)
	//1 0 0 clkI/O/256 (From prescaler)
	//1 0 1 clkI/O/1024 (From prescaler)
	//TCCR1B = 1;//  1/1
	TCCR1B = 2;//  1/8	1MHz 1us

	//FOC1A FOC1B �C �C �C �C �C �C
	TCCR1C = 0;
	//�C �C ICIE1 �C �C OCIE1B OCIE1A TOIE1
	TIMSK1 = 0;
}

void wait(unsigned int ticks) {
	TCNT1 = 0;//timer reset
	TIFR1 |= _BV(TOV1);//overflow flg reset
	while(currTick<ticks)
	{
		;
	}
}

void loop() {
	for(;;)
	{
		TCNT1 = 0;//timer reset
		TIFR1 |= _BV(TOV1);//overflow flg reset
		adj();
		flg=~flg;
		if(Power)
		{
			CmdPWROn;
		}
		else
		{
			CmdPWROff;
		}
		if(waita())
		{
			CmdPWROff;
			waitb();
		}
		else
		{
			//afterdelay
			unsigned int temp = currTick + (rpm>>1);
			while(currTick<temp)
			{
			}
			CmdPWROff;
		}
		CmdNextStep;
		rpm = currTick;
	}
}

byte waita() {
	unsigned int temp = (rpm>>2);//(rpm>>2)+40 or +80 //big for slow ,small for fast 
	//pre wait time
	while(currTick<temp)
	{
	}
	valbase = GetDigitReadBaseVal;//;//;GetDigitRead
	while(true)
	{
		byte val = GetDigitRead;
		if(val!=valbase){
			return 0;
		}
		if(currTick>MaxPonTime){
			return 0x0FF;
		}
	}
}

void waitb() {
	while(true)
	{
		byte val = GetDigitRead;
		if(val!=valbase)
		{
			return;
		}
	}
}


void adj() {
	if(Status == 1)
	{
		if(rpm>HaltRpm)//too slow, halt
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Status = 0;//halt
			Power = 0;
		}
		else
		{
			Power = 0x0FF;//Idle Power
		}
	}
	else
	{
		Power = 0;
		if(rpm<StartRpm&&rpm>(StartRpm>>3))//fast enough but not too fast
		{
			StartUpCount1++;
		}
		else
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Power = 0;
		}
		if(StartUpCount1>20)
		{
			Power = 0x0FF;
		}
		else
		{ 
			Power = 0;
		}
		if(rpm<HaltRpm&&rpm>(HaltRpm>>3))//fast enough but not too fast
		{ 
			StartUpCount2++;
		}
		else
		{ 
			StartUpCount2=0;
		}
		if(StartUpCount2>20)
		{
			Status=1;
		}
	}
}




