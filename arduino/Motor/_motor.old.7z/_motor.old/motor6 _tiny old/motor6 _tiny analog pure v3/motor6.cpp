#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "motor6.h"

//a6 start signal / restartup signal
//a7 throttle

#define HaltRpm  11000
#define StartRpm 12000

#define CmdNextStep Step = NextStep[Step];
uint8_t NextStep[] = {
  1,  2,  3,  4,  5,  0
};
//pwm on
#define CmdPWROn  PORT6O = PWR_ON[Step];
//pwm off
#define CmdPWROff PORT6O = PWR_OFF[Step];

//�±۳���
uint8_t PWR_ON[] = {
	BP1U + BP1D + BP3D, // 1-2
	BP1U + BP1D + BP2D, // 1-3
	BP2U + BP1D + BP2D, // 2-3
	BP2U + BP3D + BP2D, // 2-1
	BP3U + BP3D + BP2D, // 3-1
	BP3U + BP1D + BP3D  // 3-2
};
uint8_t PWR_OFF[] = {
	0    + BP1D + BP3D, // 1-2
	0    + BP1D + BP2D, // 1-3
	0    + BP1D + BP2D, // 2-3
	0    + BP3D + BP2D, // 2-1
	0    + BP3D + BP2D, // 3-1
	0    + BP1D + BP3D  // 3-2
};

#define GetDigitRead (PIN3I & DigitRead[Step])
uint8_t DigitRead[] = {
  BP3A,  BP2A,  BP1A,  BP3A,  BP2A,  BP1A 
};
#define GetDigitReadBaseVal (DigitReadBaseVal[Step])
uint8_t DigitReadBaseVal[] = {
  BP3A,     0,  BP1A,     0,  BP2A,     0
};

PROGMEM prog_uint16_t PWR_Table[] = {2500,2415,2335,2261,2191,2126,2064,2006,1951,1899,1849,1802,1758,1715,1675,1636,1600,1564,1531,1498,1467,1438,1409,1382,1355,1330,1306,1282,1259,1237,1216,1196,1176,1157,1138,1120,1103,1086,1070,1054,1038,1024,1009,995,981,968,955,942,930,918,906,895,883,873,862,852,842,832,822,813,804,795,786,777,769,760,752,745,737,729,722,715,707,700,694,687,680,674,668,661,655,649,643,638,632,626,621,615,610,605,600,595,590,585,580,576,571,566,562,557,553,549,545,540,536,532,528,525,521,517,513,509,506,502,499,495,492,488,485,482,479,475,472,469,466,463,460,457,454,451,448,445,443,440,437,435,432,429,427,424,422,419,417,414,412,409,407,405,403,400,398,396,394,391,389,387,385,383,381,379,377,375,373,371,369,367,365,363,361,360,358,356,354,353,351,349,347,346,344,342,341,339,337,336,334,333,331,330,328,327,325,324,322,321,319,318,316,315,314,312,311,309,308,307,305,304,303,302,300,299,298,296,295,294,293,292,290,289,288,287,286,285,283,282,281,280,279,278,277,276,275,274,273,271,270,269,268,267,266,265,264,263,262,261,261,260,259,258,257,256,255,254,253,252,251,250};

PROGMEM prog_uint16_t StartUp_Table[] = {24999,24150,23357,22614,21917,21262,20645,20062,19512,18991,18497,18028,17582,17158,16753,16368,16000,15647,15311,14988,14678,14382,14096,13822,13559,13305,13061,12825,12598,12379,12167,11962,11764,11573,11387,11208,11034,10865,10702,10543,10389,10240,10094,9953,9815,9682,9552,9425,9302,9182,9065,8951,8839,8731,8625,8521,8421,8322,8226,8132,8040,7950,7862,7776,7692,7609,7529,7450,7373,7297,7223,7150,7079,7009,6941,6874,6808,6743,6680,6618,6557,6497,6438,6380,6324,6268,6213,6159,6106,6054,6003,5953,5904,5855,5807,5760,5714,5668,5623,5579,5536,5493,5451,5409,5369,5328,5289,5250,5211,5173,5136,5099,5063,5027,4992,4957,4923,4889,4855,4822,4790,4758,4726,4695,4664,4634,4604,4574,4545,4516,4488,4459,4432,4404,4377,4350,4324,4298,4272,4246,4221,4196,4172,4147,4123,4099,4076,4053,4030,4007,3985,3962,3940,3919,3897,3876,3855,3834,3814,3793,3773,3753,3733,3714,3695,3676,3657,3638,3619,3601,3583,3565,3547,3530,3512,3495,3478,3461,3444,3427,3411,3395,3379,3363,3347,3331,3316,3300,3285,3270,3255,3240,3225,3211,3196,3182,3168,3154,3140,3126,3112,3099,3085,3072,3059,3046,3033,3020,3007,2994,2982,2969,2957,2945,2933,2921,2909,2897,2885,2873,2862,2850,2839,2828,2816,2805,2794,2783,2772,2762,2751,2740,2730,2719,2709,2699,2689,2678,2668,2658,2649,2639,2629,2619,2610,2600,2591,2581,2572,2563,2553,2544,2535,2526,2517,2508};

uint8_t Power = 0;
uint8_t Step = 0;
uint8_t Status = 0;//0 halt ,1 running, 2 starting
uint8_t StartUpCount1=0;
uint8_t StartUpCount2=0;
uint16_t rpm;
uint8_t startupIndex;
uint16_t startupCurrent;

void ClockInit();
void TimerInit();
void AnalogInit();
void wait(unsigned int ticks);
void loop();
void waita();
void adj();
void startup();


int main(void) {
	ClockInit();//��ʼ��ʱ�ӣ�1MHz -> 8MHz
	TimerInit();//��ʼ����ʱ�� 1/8
	AnalogInit();//��ʼ��ģ������

	DDRA = 0;PORTA = 0;//all input
	DDRB = 0;PORTB = 0;//all input

	//�ȴ�1�������ź� Pin6�ߵ�ƽ  wait till 1s power on signal
	int cnt = 0;
	while(true)
	{
		wait(1000);
		if(drA6==0)// power on signal
		{
			cnt=0;
		}
		cnt++;
		if(cnt>=1000)
		{
			break;
		}
	}

	//������˿�
	DDR6O = BP1U | BP1D | BP2U | BP2D | BP3U | BP3D;
	
	//��ʼ������˿�
	PORT6O = BP1D | BP2D | BP3D;
	
	//��ʼ������˿�
	DDR3I = 0;
	PORT3I = 0;

	//��ѭ��
	loop();
}

void wait(unsigned int ticks) {
	TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
	while(currTick<ticks)
	{
		;
	}
}

void ClockInit() {
	CLKPR = 128;//The CLKPCE bit must be written to logic one to enable change of the CLKPS bits. The CLKPCE bit is only updated when the other bits in CLKPR are simultaniosly written to zero.
	//CLKPR = 3;//1/8
	CLKPR = 0;//1/1 //8MHz
}

void TimerInit() {
	TCCR1A = 0;
	TCCR1B = 2;//  1/8	1MHz 1us
	TCCR1C = 0;
	TIMSK1 = 0;
}

void AnalogInit() {
	ADMUX = 7;//A7 rpm
	ADCSRA = _BV(ADEN) | _BV(ADSC) | _BV(ADPS0) | _BV(ADPS1) | _BV(ADPS2);
	ADCSRB = _BV(ADLAR);
}

void loop() {
	for(;;) {
		//��ʱ������
		TCNT1 = 0;TIFR1 |= _BV(TOV1);//timer reset //overflow flg reset
		adj();
		//����
		if(Power)
		{
			CmdPWROn;
		}
		else
		{
			CmdPWROff;
		}
		//�ȴ�����
		waita();
		CmdNextStep;
		//��¼��ǰת��
		rpm = currTick;
	}
}

void waita() {
	if(Status == 2)
	{
		while(true)
		{
			//����ر� 1/4 ����
			if(currTick>MaxPonTime){
				CmdPWROff;
			}
			if(currTick>startupCurrent){
				CmdPWROff;
				return;
			}
		}
	}
	else
	{
		uint16_t temp = (rpm>>1);//(rpm>>2)+40 or +80 //big for slow ,small for fast 
		//pre wait time
		while(currTick<temp){}
		uint8_t valbase = GetDigitReadBaseVal;//;//;GetDigitRead
		while(true)
		{
			uint8_t val = GetDigitRead;
			if(val!=valbase){
				CmdPWROff;
				return;
			}
			if(currTick>MaxPonTime){
				CmdPWROff;
			}
			if(drA6)// power on signal
			{
				startup();
			}
		}
	}
}

void adj() {
	Power = 0;
	uint8_t aread = ADCH;
	uint16_t TargetRPM = pgm_read_word_near(PWR_Table + aread);// TODO 512byte convert table  *32 8000max  ticks<<5
	sbi(ADCSRA, ADSC);
	if(Status == 1)
	{
		if(rpm>HaltRpm)//too slow, halt
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
			Status = 0;//halt
		}
		else if(rpm>TargetRPM)//bit slow && running
		{
			Power = 0x0FF;
		}
	}
	else if(Status == 2)
	{
		startupIndex++;
		startupCurrent = pgm_read_word_near(StartUp_Table + startupIndex);
		Power = 0x0FF;
		if(startupIndex == 255)
		{
			Status = 1;
		}
	}
	else
	{
		if(rpm<StartRpm&&rpm>(StartRpm>>3))//fast enough but not too fast
		{
			StartUpCount1++;
		}
		else
		{
			StartUpCount1 = 0;
			StartUpCount2 = 0;
		}
		if(StartUpCount1>20)
		{
			Power = 0x0FF;
		}
		if(rpm<HaltRpm&&rpm>(HaltRpm>>3))//fast enough but not too fast
		{ 
			StartUpCount2++;
		}
		else
		{ 
			StartUpCount2=0;
		}
		if(StartUpCount2>20)
		{
			Status = 1;
		}
	}
}

void startup()
{
	//��ǰ�۶�׼
	for(uint8_t i=0;i<255;i++)
	{
		CmdPWROn;
		wait(100);
		CmdPWROff;
		wait(1000);
	}
	startupIndex = 0;
	Status = 2;
}


