#define byte uint8_t

#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif


#define currTick ((TIFR1 & _BV(TOV1))?0x0FFFF:TCNT1)

//ADPS2 ADPS1 ADPS0
//000 2	x	x
//001 2	x	x
//010 4	4M	5.9
//*011 8	2M	7.4
//100 16	1M	8.7
//101 32	500k	9.4   36us/time
//110 64	250k	9.5
//111 128	125k	9.6  
#define initAnalog cbi(ADCSRA,ADPS2);sbi(ADCSRA,ADPS1);sbi(ADCSRA,ADPS0);

//8	PB,8	_BV(0),
#define dwP10H PORTB |=  _BV(2);
#define dwP10L PORTB &= ~_BV(2);
#define dwP10T PINB  |=  _BV(2);
#define dwP11H PORTB |=  _BV(3);
#define dwP11L PORTB &= ~_BV(3);
#define dwP12H PORTB |=  _BV(4);
#define dwP12L PORTB &= ~_BV(4);
#define dwP13H PORTB |=  _BV(5);
#define dwP13L PORTB &= ~_BV(5);

//drA3
#define drA3 (PINC & _BV(3))

#define drA4 (PINC & _BV(4))

//drP8
#define drPok (PINB & _BV(0)?0:0x0FF)

//A2 A1 A0
//2 3 4 5 6 7
#define PORT6O PORTD
#define DDR6O DDRD

#define PORT3I PORTC
#define DDR3I DDRC
#define PIN3I PINC

#define NOOP 0
#define BP1U _BV(7)
#define BP1D _BV(6)
#define BP1A _BV(0)
#define BP2U _BV(5)
#define BP2D _BV(4)
#define BP2A _BV(1)
#define BP3U _BV(3)
#define BP3D _BV(2)
#define BP3A _BV(2)
