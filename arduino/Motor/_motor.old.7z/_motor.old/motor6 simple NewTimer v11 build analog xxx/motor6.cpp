#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "motor6.h"

#define IdleRpm  1000
#define HaltRpm  7000
#define StartRpm 8000
#define MaxPonTime 1000


#define CmdNextStep Step = pgm_read_byte_near(NextStep+Step);
PROGMEM prog_uint8_t NextStep[] = {
  1,  2,  3,  4,  5,  0
};

// init: uL dH
//if(POn){s1onA;}else{s1onB;}
//power on
#define CmdOnPwr PORT6O |= (pgm_read_byte_near(BitUp+Step) & POn);
//bypass on
#define CmdOnBypass PORT6O &= (~pgm_read_byte_near(BitUp+Step) | POn);
//turnoff first
#define CmdOffFirst PORT6O &= ~(pgm_read_byte_near(BitUp+Step) & POn);
PROGMEM prog_uint8_t BitUp[] = {
  BP1U,  BP1U,  BP2U,  BP2U,  BP3U,  BP3U
};

//same
#define CmdOnSame PORT6O &= ~(pgm_read_byte_near(OnSame+Step));
PROGMEM prog_uint8_t OnSame[] = {
  NOOP,  BP3D,  NOOP,  BP1D,  NOOP,  BP2D
};

//turnoff after
#define CmdOffAfter PORT6O |= (pgm_read_byte_near(OffAfter+Step));
PROGMEM prog_uint8_t OffAfter[] = {
  BP2D,  NOOP,  BP3D,  NOOP,  BP1D,  NOOP
};

#define GetDigitRead (PIN3I & pgm_read_byte_near(DigitRead+Step))
PROGMEM prog_uint8_t DigitRead[] = {
  BP3A,  BP2A,  BP1A,  BP3A,  BP2A,  BP1A 
};

#define GetDigitReadBaseVal (pgm_read_byte_near(DigitReadBaseVal+Step))
PROGMEM prog_uint8_t DigitReadBaseVal[] = {
  BP3A,     0,  BP1A,     0,  BP2A,     0
};

PROGMEM  prog_uint8_t  PowerData[] = {
0xff,0x7f,0xbf,0x3f,0xdf,0x5f,0x9f,0x1f,0xef,0x6f,0xaf,0x2f,0xcf,0x4f,0x8f,0x0f,
0xf7,0x77,0xb7,0x37,0xd7,0x57,0x97,0x17,0xe7,0x67,0xa7,0x27,0xc7,0x47,0x87,0x07,
0xfb,0x7b,0xbb,0x3b,0xdb,0x5b,0x9b,0x1b,0xeb,0x6b,0xab,0x2b,0xcb,0x4b,0x8b,0x0b,
0xf3,0x73,0xb3,0x33,0xd3,0x53,0x93,0x13,0xe3,0x63,0xa3,0x23,0xc3,0x43,0x83,0x03,
0xfd,0x7d,0xbd,0x3d,0xdd,0x5d,0x9d,0x1d,0xed,0x6d,0xad,0x2d,0xcd,0x4d,0x8d,0x0d,
0xf5,0x75,0xb5,0x35,0xd5,0x55,0x95,0x15,0xe5,0x65,0xa5,0x25,0xc5,0x45,0x85,0x05,
0xf9,0x79,0xb9,0x39,0xd9,0x59,0x99,0x19,0xe9,0x69,0xa9,0x29,0xc9,0x49,0x89,0x09,
0xf1,0x71,0xb1,0x31,0xd1,0x51,0x91,0x11,0xe1,0x61,0xa1,0x21,0xc1,0x41,0x81,0x01,
0xfe,0x7e,0xbe,0x3e,0xde,0x5e,0x9e,0x1e,0xee,0x6e,0xae,0x2e,0xce,0x4e,0x8e,0x0e,
0xf6,0x76,0xb6,0x36,0xd6,0x56,0x96,0x16,0xe6,0x66,0xa6,0x26,0xc6,0x46,0x86,0x06,
0xfa,0x7a,0xba,0x3a,0xda,0x5a,0x9a,0x1a,0xea,0x6a,0xaa,0x2a,0xca,0x4a,0x8a,0x0a,
0xf2,0x72,0xb2,0x32,0xd2,0x52,0x92,0x12,0xe2,0x62,0xa2,0x22,0xc2,0x42,0x82,0x02,
0xfc,0x7c,0xbc,0x3c,0xdc,0x5c,0x9c,0x1c,0xec,0x6c,0xac,0x2c,0xcc,0x4c,0x8c,0x0c,
0xf4,0x74,0xb4,0x34,0xd4,0x54,0x94,0x14,0xe4,0x64,0xa4,0x24,0xc4,0x44,0x84,0x04,
0xf8,0x78,0xb8,0x38,0xd8,0x58,0x98,0x18,0xe8,0x68,0xa8,0x28,0xc8,0x48,0x88,0x08,
0xf0,0x70,0xb0,0x30,0xd0,0x50,0x90,0x10,0xe0,0x60,0xa0,0x20,0xc0,0x40,0x80,0x00
};

byte Count256;
byte Power = 0;
byte PowerMon = 0;
byte Step = 0;
byte Status = 0;//0 halt ,1 running, 2 starting
byte StartUpCount1=0;
byte StartUpCount2=0;
byte valbase;

unsigned int rpm;

void TimerInit();
void AnalogInit();
void loop();
byte waita();
void waitb();
void adj();


int main(void){
  TimerInit();
  AnalogInit();

  //INPUT
  //    DDR &= ~_BV();PORT &= ~_BV();
  //output
  //    DDR |= _BV();
  //DDR6O |= BP1U;//pMode(p1u, OUTPUT);//     7
  //DDR6O |= BP1D;//pMode(p1d, OUTPUT);//     6
  //DDR6O |= BP2U;//pMode(p2u, OUTPUT);//     5
  //DDR6O |= BP2D;//pMode(p2d, OUTPUT);//     4
  //DDR6O |= BP3U;//pMode(p3u, OUTPUT);//     3
  //DDR6O |= BP3D;//pMode(p3d, OUTPUT);//     2
  DDR6O = BP1U | BP1D | BP2U | BP2D | BP3U | BP3D;//DDRD

  //#define turnoffAll p1uL;p2uL;p3uL;p1dH;p2dH;p3dH;
  //PORT6O &= ~BP1U; //up    A2
  //PORT6O |=  BP1D; //down
  //PORT6O &= ~BP2U; //up    A1
  //PORT6O |=  BP2D; //down
  //PORT6O &= ~BP3U; //up    A0
  //PORT6O |=  BP3D; //down
  PORT6O = BP1D | BP2D | BP3D;//PORTD

  //DDRC &= ~BP1A;PORTC &= ~BP1A;//pMode(A0, INPUT);//INPUT_PULLUP for comparator
  //DDRC &= ~BP2A;PORTC &= ~BP2A;//pMode(A1, INPUT);//digit
  //DDRC &= ~BP3A;PORTC &= ~BP3A;//pMode(A2, INPUT);//digit
  DDR3I = 0;//DDRC
  PORT3I = 0;//PORTC
  
  DDRB &= ~_BV(0);PORTB &= ~_BV(0);//pMode(8, INPUT);//digit
  DDRB &= ~_BV(1);PORTB &= ~_BV(1);//pMode(9, INPUT);//digit

  DDRB |= _BV(2);//pMode(10, OUTPUT);
  DDRB |= _BV(3);//pMode(11, OUTPUT);
  DDRB |= _BV(4);//pMode(12, OUTPUT);
  DDRB |= _BV(5);//pMode(13, OUTPUT);    

  //DDRC &= ~_BV(3);PORTC &= ~_BV(3);//pMode(A3, INPUT);//analogInput

  for(;;)
  {
    loop();
  }
  
}

void TimerInit() {
	// COM1A1 COM1A0 COM1B1 COM1B0 �C �C WGM11 WGM10
	TCCR1A = 0;

	//ICNC1 ICES1 �C WGM13 WGM12 CS12 CS11 CS10
	//0 0 1 clkI/O/1 (No prescaling)
	//0 1 0 clkI/O/8 (From prescaler)
	//0 1 1 clkI/O/64 (From prescaler)
	//1 0 0 clkI/O/256 (From prescaler)
	//1 0 1 clkI/O/1024 (From prescaler)
	//TCCR1B = 1;//  1/1
	TCCR1B = 2;//  1/8

	//FOC1A FOC1B �C �C �C �C �C �C
	TCCR1C = 0;
	//�C �C ICIE1 �C �C OCIE1B OCIE1A TOIE1
	TIMSK1 = 0;
}

void AnalogInit()
{
	ADMUX = 3;
	sbi(ADMUX,ADLAR);
	sbi(ADMUX,ADLAR);
	cbi(ADMUX,REFS1);
	sbi(ADMUX,REFS0);
	ADCSRA = 0;
	sbi(ADCSRA,ADEN);
	sbi(ADCSRA,ADSC);
	sbi(ADCSRA,ADPS0);//  1/128
	sbi(ADCSRA,ADPS1);
	sbi(ADCSRA,ADPS2);
	ADCSRB = 0;
}

void loop() {
  TCNT1 = 0;//timer reset
  TIFR1 |= _BV(TOV1);//overflow flg reset
  byte POn = Power & PowerMon;
  CmdOnPwr;
  CmdOnBypass;
  CmdOnSame;
  dwP10T;
  Count256++;
  adj();
  if(waita())
  {
    PowerMon = drPok;
    CmdOffFirst;
    waitb();
    CmdOffAfter;
  }
  else
  {
    //afterdelay
    unsigned int temp = currTick + (rpm>>3);
    while(currTick<temp)
    {
    }
    PowerMon = drPok;
    CmdOffFirst;
    CmdOffAfter;
  }
  CmdNextStep;
  rpm = currTick;
}


char waita()
{
  unsigned int temp = (rpm>>1);//(rpm>>2)+40 or +80 //big for slow ,small for fast 
  while(currTick<temp)
  {
    //pre wait time
  }
  valbase = GetDigitReadBaseVal;//;//;GetDigitRead
  while(true)
  {
    byte val = GetDigitRead;
    if(currTick>MaxPonTime){
      return 0x0FF;
    }
    if(val!=valbase){
      return 0;
    }
  }
}

void waitb()
{
  while(true)
  {
    byte val = GetDigitRead;
    if(val!=valbase)
    {
      return;
    }
  }
}

void adj()
{
  byte aread = ADCH;
  sbi(ADCSRA, ADSC);//startAdc
  byte TargetPower = pgm_read_byte_near(PowerData + Count256)>aread?0:0x0FF;
  if(Status == 1)
  {
    dwP13H;
    if(rpm>HaltRpm)//too slow, halt
    {
      Status = 0;//halt
      StartUpCount1 = 0;
      StartUpCount2 = 0;
      Power = 0;
    }
    else if(rpm>IdleRpm)//bit slow && running
    {
		Power = 0x0FF;
		//byte val = rpm - IdleRpm;
		//Power = pgm_read_byte_near(PowerData + Count256)>val?0:0x0FF;
    }
    else//fast
    {
      Power = TargetPower;
    }
  }
  else
  {
    dwP13L;
    if(rpm<StartRpm&&rpm>(StartRpm>>3))//fast enough but not too fast
    {
      StartUpCount1++;
    }
    else
    {
      StartUpCount1 = 0;
      StartUpCount2 = 0;
      Power = 0;
    }
	
    if(StartUpCount1>10)
    {
      Power = 0x0FF;
    }
    else
    { 
      Power = 0;
    }
	
    if(rpm<HaltRpm&&rpm>(HaltRpm>>3))//fast enough but not too fast
    { 
      StartUpCount2++;
    }
    else
    { 
      StartUpCount2=0;
    }
    if(StartUpCount2>10)
    {
      Status=1;
    }
  }
}







