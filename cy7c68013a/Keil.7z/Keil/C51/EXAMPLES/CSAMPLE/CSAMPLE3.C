/*------------------------------------------------------------------------------
CSAMPLE3.C

Copyright 1995-1999 Keil Software, Inc.
------------------------------------------------------------------------------*/

#include <stdio.h>                             /* define I/O functions */

char dummy_buffer [25];                        /* only for demostration */
 
void output (unsigned int number)  {
  printf ("\nresult: %d\n\n", number);
}
