/*------------------------------------------------------------------------------
BADCODE.C

Copyright 1995-1999 Keil Software, Inc.

This source file is full of errors.  You can use �Vision/51 to compile and
correct errors in this file.
------------------------------------------------------------------------------*/

#incldue <stdio.h>

void main (void, void)
{
unsigned i;
long fellow;

fellow = 0;

fer (i = 0; i < 1OOO; i++)
  {
  printf ("I is %u\n", i);

  fellow += i;
  printf ("Fellow = %ld\n, fellow);
  printf ("End of loop\n")
  }
}


