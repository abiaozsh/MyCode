using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;
using myd3d;

namespace Electric
{
	[Serializable]
	public class Point3D
	{
		public float x;
		public float y;
		public float z;
	}

	[Serializable]
	public class PSpot
	{
		[NonSerialized]
		public Model model;
		public Text name;
		public string sname;

		public double posx;

		public double posy;

		public double posz;

		public bool _static;

		public double headingx;

		public double headingy;

		public double headingz;

		public double charge;

		public double mass;

		public double process;

		public override string ToString()
		{
			return sname + " charge:" + charge.ToString();
		}

		public static void ProcessGravity(List<PSpot> spotList, bool slowdown, double temperature)
		{
			Random rnd = new Random();
			while (true)
			{
				double process = 1;
				PSpot sp = null;
				foreach (PSpot s in spotList)
				{
					if (s.process < process)
					{
						process = s.process;
						sp = s;
					}
				}
				if (sp != null)
				{
					sp.CalcGravity(spotList, rnd, slowdown, temperature);
				}
				else
				{
					break;
				}
			}
		}

		static double G = 0.01;
		static double E = 0.01;

		public void CalcGravity(List<PSpot> allSpot, Random rnd, bool slowdown, double temperature)
		{
			if (this._static)
			{
				process = 1;
				return;
			}

			double forceX = 0;
			double forceY = 0;
			double forceZ = 0;
			double reduce = 0;

			double d = 2;//midpoint
			double b = 30;//force
			double a = d * b / 2;

			foreach (PSpot s in allSpot)
			{
				if (s != this)
				{
					double diffx = s.posx - posx;
					double diffy = s.posy - posy;
					double diffz = s.posz - posz;
					double r2 = diffx * diffx + diffy * diffy + diffz * diffz;
					double r = Math.Sqrt(r2);
					double e = this.charge * s.charge;

					if (r == 0)
					{
						posx += 0.01;
						posy += 0.01;
						posz += 0.01;
						continue;
					}
					reduce += 1 / r;

					double f1;
					{

						if (Math.Sign(this.charge) == Math.Sign(s.charge))
						{
							f1 = -E * e * a / r2;
						}
						else
						{
							if (r < d)
							{
								double n = -a / r + b;
								double f = -E * e * n;
								f1 = f / r;
							}
							else
							{
								f1 = -E * e * a / r2;
							}
						}
					}

					forceX += f1 * diffx;
					forceY += f1 * diffy;
					forceZ += f1 * diffz;
				}
			}
			reduce /= allSpot.Count;

			forceX /= mass;
			forceY /= mass;
			forceZ /= mass;

			double force = Math.Sqrt(forceX * forceX + forceY * forceY + forceZ * forceZ);

			if (force > 0)
			{
				double gate = 0.001;
				double step = gate / force;

				if (process + step < 1)
				{
					process += step;

					headingx += forceX * step;
					headingy += forceY * step;
					headingz += forceZ * step;

					posx += headingx * step;
					posy += headingy * step;
					posz += headingz * step;
				}
				else
				{
					step = 1 - process;
					process = 1;
					headingx += forceX * step;
					headingy += forceY * step;
					headingz += forceZ * step;

					posx += headingx * step;
					posy += headingy * step;
					posz += headingz * step;

					if (slowdown)
					{
						headingx = headingx * 0.5;
						headingy = headingy * 0.5;
						headingz = headingz * 0.5;
					}

					headingx += (rnd.NextDouble() - 0.5) * temperature / mass;
					headingy += (rnd.NextDouble() - 0.5) * temperature / mass;
					headingz += (rnd.NextDouble() - 0.5) * temperature / mass;

				}

			}
			else
			{
				posx += headingx;
				posy += headingy;
				posz += headingz;
				process = 1;
			}
		}
	}
}
