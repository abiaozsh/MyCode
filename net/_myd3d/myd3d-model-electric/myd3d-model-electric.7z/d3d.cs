using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using Electric;

namespace myd3d
{
	public class Form1 : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			InitializeComponent();
		}
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(144, 96);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseMove += new MouseEventHandler(pictureBox1_MouseMove);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(162, 12);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(144, 96);
			this.pictureBox2.TabIndex = 0;
			this.pictureBox2.TabStop = false;
			// 
			// listBox1
			// 
			this.listBox1.FormattingEnabled = true;
			this.listBox1.ItemHeight = 12;
			this.listBox1.Location = new System.Drawing.Point(12, 114);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(294, 148);
			this.listBox1.TabIndex = 1;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(12, 270);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// trackBar1
			// 
			this.trackBar1.LargeChange = 10;
			this.trackBar1.Location = new System.Drawing.Point(93, 270);
			this.trackBar1.Maximum = 100;
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(213, 42);
			this.trackBar1.TabIndex = 3;
			this.trackBar1.TickFrequency = 10;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(318, 305);
			this.Controls.Add(this.trackBar1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "3D";
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		[STAThread]
		static void Main()
		{
			Application.Run(new Form1());
		}


		////////////////////////////////////////////////////////////////////
		D3DDevice device;

		public int traceIdx;
		bool keyDw = false;
		bool keyUp = false;
		bool keyRt = false;
		bool keyLt = false;
		private PictureBox pictureBox1;
		private PictureBox pictureBox2;

		bool start = false;
		private ListBox listBox1;
		private Button button1;
		private TrackBar trackBar1;

		private Line baseline;

		List<PSpot> spotList = new List<PSpot>();

		private void Form1_Load(object sender, System.EventArgs e)
		{
			device = new D3DDevice(this, pictureBox1, pictureBox2, new SetObject(this.setObject));
			init();
		}

		int spotIdx = 0;

		private void _addSpot(double posx, double posy, double posz, double headingx, double headingy, double headingz, List<PSpot> spotList, double mass, double charge, string texture, bool _static)
		{
			PSpot sp = new PSpot();
			sp.posx = posx;
			sp.posy = posy;
			sp.posz = posz;
			sp.headingx = headingx;
			sp.headingy = headingy;
			sp.headingz = headingz;
			sp.mass = mass;
			sp.charge = charge;
			sp._static = _static;
			sp.model = new Model(device, "moon.x", texture);
			device.addObject(sp.model);

			System.Drawing.Font f = new System.Drawing.Font("simsun", 12);
			sp.sname = spotIdx.ToString();
			sp.name = new Text(device, (spotIdx++).ToString(), f, 0, 0.1f);
			device.addObject(sp.name);

			listBox1.Items.Add(sp);
			spotList.Add(sp);
		}

		private void init()
		{
			baseline = new Line(device);
			baseline.addLine(0, 0, 0, 1, 0, 0, 0xFF0000);
			baseline.addLine(0, 0, 0, 0, 1, 0, 0x00FF00);
			baseline.addLine(0, 0, 0, 0, 0, 1, 0x0000FF);
			baseline.Finish();
			device.addObject(baseline);
		}

		bool slowdown = true;

		private void Form1_KeyDown(object sender, KeyEventArgs e)
		{
			D3DCamera cam = device.cam;
			if (e.KeyCode == Keys.Escape)
			{
				this.Dispose(true); return;
			}
			if (e.KeyCode == Keys.F1)
			{
				slowdown = !slowdown;
			}
			if (e.KeyCode == Keys.Right) keyRt = true;
			if (e.KeyCode == Keys.Left) keyLt = true;
			if (e.KeyCode == Keys.Up) keyUp = true;
			if (e.KeyCode == Keys.Down) keyDw = true;
			if (e.KeyCode == Keys.D1)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 1, 1, "root.bmp", false);
				_addSpot(x + 1, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
			}
			if (e.KeyCode == Keys.D2)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 2, 2, "root.bmp", false);
				//_addSpot(x + 1, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				//_addSpot(x + 2, y + 0.1, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
			}
			if (e.KeyCode == Keys.D3)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 3, 3, "root.bmp", false);
				_addSpot(x + 1, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 2, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 3, y + 0.1, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
			}
			if (e.KeyCode == Keys.D4)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 4, 4, "root.bmp", false);
				_addSpot(x + 1, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 2, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 3, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 4, y + 0.1, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
			}
			if (e.KeyCode == Keys.D5)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 5, 5, "root.bmp", false);
				_addSpot(x + 1, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 2, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 3, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 4, y, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				_addSpot(x + 5, y + 0.1, z, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
			}
			if (e.KeyCode == Keys.D6)
			{
				double x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				double y = cam.y + (float)(10 * Math.Sin(cam.angle));
				double z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				_addSpot(x, y, z, 0, 0, 0, spotList, 12, 12, "root.bmp", false);
				Random r = new Random();
				for (int i = 0; i < 12; i++)
				{
					double x1 = r.NextDouble() * 2 - 1;
					double y1 = r.NextDouble() * 2 - 1;
					double z1 = r.NextDouble() * 2 - 1;
					_addSpot(x + x1, y + y1, z + z1, 0, 0, 0, spotList, 1, -1, "MOON.bmp", false);
				}
			}
			if (e.KeyCode == Keys.Space)
			{
				D3DObject obj = device.GetObject(mousex, mousey);
				foreach (PSpot p in spotList)
				{
					if (p.model == obj)
					{
						listBox1.SelectedItem = p;
						listBox1.Refresh();
					}
				}
			}
			e.Handled = true;
		}
		int mousex = 0;
		int mousey = 0;
		private void Form1_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Right) keyRt = false;
			if (e.KeyCode == Keys.Left) keyLt = false;
			if (e.KeyCode == Keys.Up) keyUp = false;
			if (e.KeyCode == Keys.Down) keyDw = false;
		}

		private void setObject()
		{
			D3DCamera cam = device.cam;
			{
				float x = cam.x + (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				float y = cam.y + (float)(10 * Math.Sin(cam.angle));
				float z = cam.z + (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				//baseline.zoom(1, 1, 1);
				baseline.reset_matrix();
				baseline.zoom(2, 2, 2);
				baseline.move(x, y, z);
			}

			PSpot sp = (PSpot)listBox1.SelectedItem;
			if (keyUp)
			{
				float x = (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				float y = (float)(10 * Math.Sin(cam.angle));
				float z = (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				sp.headingx += x / 10;
				sp.headingy += y / 10;
				sp.headingz += z / 10;
			}
			if (keyDw)
			{
				float x = (float)(10 * Math.Sin(cam.direction) * Math.Cos(cam.angle));
				float y = (float)(10 * Math.Sin(cam.angle));
				float z = (float)(10 * Math.Cos(cam.direction) * Math.Cos(cam.angle));
				sp.headingx -= x / 10;
				sp.headingy -= y / 10;
				sp.headingz -= z / 10;
			}


			if (true)
			{
				foreach (PSpot s in spotList)
				{
					s.process = 0;
				}
				PSpot.ProcessGravity(spotList, slowdown, 0.01 * this.trackBar1.Value);
			}

			float scale = 1;
			foreach (PSpot p in spotList)
			{
				p.model.visible = p.mass != 0;
				p.model.reset_matrix();
				float size = (float)(Math.Sqrt(p.mass)) / 40;
				p.model.zoom(size, size, size);
				p.model.move((float)p.posx * scale, (float)p.posy * scale, (float)p.posz * scale);

				p.name.visible = false;// p.mass != 0;
				p.name.reset_matrix();
				p.name.move(0.2f, 0.2f, 0.2f);
				p.name.zoom(0.4f, 0.4f, 0.4f);
				p.name.move((float)p.posx * scale, (float)p.posy * scale, (float)p.posz * scale);
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			PSpot sp = (PSpot)listBox1.SelectedItem;
			if (sp == null)
			{
				sp = (PSpot)listBox1.Items[0];
			}
			if (sp == null)
			{
				return;
			}
			device.removeObject(sp.model);
			device.removeObject(sp.name);
			spotList.Remove(sp);
			listBox1.Items.Remove(sp);
		}

		void pictureBox1_MouseMove(object sender, MouseEventArgs e)
		{
			mousex = e.X;
			mousey = e.Y;
		}


	}
}
